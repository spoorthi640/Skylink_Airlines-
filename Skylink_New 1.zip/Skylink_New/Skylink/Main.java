// ------------------------------------------------------------
// Main.java
// Application entry point
// ------------------------------------------------------------

import javax.swing.*;
import gui.*;
import services.*;
import models.*;



public class Main {
    public static void main(String[] args) {

        // Load data from files
        DataStore.init();

        // Show login window
        SwingUtilities.invokeLater(() -> new LoginGUI());
    }
}
