// -----------------------------------------------------------------------------
// DataStore.java
// Handles loading & saving of Users, Flights, Bookings using text files.
// Demonstrates: File Handling (java.io), Collections, Exception Handling
// -----------------------------------------------------------------------------
package services;

import models.*;

import java.io.*;
import java.util.*;

public class DataStore {

    // Folder + file paths
    public static final String DATA_FOLDER = "data";
    public static final String USERS_FILE = DATA_FOLDER + File.separator + "users.txt";
    public static final String FLIGHTS_FILE = DATA_FOLDER + File.separator + "flights.txt";
    public static final String BOOKINGS_FILE = DATA_FOLDER + File.separator + "bookings.txt";

    // In-memory datasets
    public static HashMap<String, User> users = new HashMap<>();
    public static ArrayList<Flight> flights = new ArrayList<>();
    public static ArrayList<Booking> bookings = new ArrayList<>();


    // Called at program startup
    public static void init() {
        try {
            // Create data folder if missing
            File dir = new File(DATA_FOLDER);
            if (!dir.exists()) dir.mkdir();

            // Create files if missing
            File u = new File(USERS_FILE);
            File f = new File(FLIGHTS_FILE);
            File b = new File(BOOKINGS_FILE);

            if (!u.exists()) u.createNewFile();
            if (!f.exists()) f.createNewFile();
            if (!b.exists()) b.createNewFile();

            // Load data into memory
            loadUsers();
            loadFlights();
            loadBookings();

            // Create default admin if not exists
            if (!users.containsKey("admin")) {
                Admin a = new Admin("admin", "admin123", "Administrator");
                users.put(a.getUsername(), a);
                saveUsers();
            }

            // If no flights exist, add sample flights
            if (flights.isEmpty()) {
                flights.add(new Flight("FL001", "Mumbai", "Delhi", "2026-01-10", "09:00", 3500.0, 30));
                flights.add(new Flight("FL002", "Bengaluru", "Hyderabad", "2026-01-11", "13:30", 2800.0, 24));
                flights.add(new Flight("FL003", "Chennai", "Mumbai", "2026-01-12", "07:45", 3200.0, 36));
                saveFlights();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // ---------------------- USER LOADING & SAVING -------------------------

    public static void loadUsers() {
        users.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                // Format: TYPE|username|password|fullName
                String[] p = line.split("\\|");
                if (p.length < 4) continue;

                if (p[0].equals("ADMIN")) {
                    users.put(p[1], new Admin(p[1], p[2], p[3]));
                } else {
                    users.put(p[1], new Passenger(p[1], p[2], p[3]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void saveUsers() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User u : users.values()) {
                String type = (u instanceof Admin) ? "ADMIN" : "PASS";
                bw.write(type + "|" + u.getUsername() + "|" + u.getPassword() + "|" + u.getFullName());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // ---------------------- FLIGHT LOADING & SAVING -----------------------

    public static void loadFlights() {
        flights.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(FLIGHTS_FILE))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                Flight f = Flight.fromString(line);
                if (f != null) flights.add(f);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void saveFlights() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FLIGHTS_FILE))) {
            for (Flight f : flights) {
                bw.write(f.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // ---------------------- BOOKING LOADING & SAVING ----------------------

    public static void loadBookings() {
        bookings.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(BOOKINGS_FILE))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                Booking bk = Booking.fromString(line);
                if (bk != null) bookings.add(bk);

                // Restore booked seats into flight object
                if (bk != null) {
                    for (Flight f : flights) {
                        if (f.getFlightId().equals(bk.getFlightId())) {
                            if (!f.getBookedSeats().contains(bk.getSeat()))
                                f.getBookedSeats().add(bk.getSeat());
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void saveBookings() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(BOOKINGS_FILE))) {
            for (Booking b : bookings) {
                bw.write(b.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
