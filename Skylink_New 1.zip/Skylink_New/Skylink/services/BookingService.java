// -----------------------------------------------------------------------------
// BookingService.java
// Handles booking creation, lookup & cancellation
// Demonstrates: Encapsulation + Service interaction + Data consistency
// -----------------------------------------------------------------------------
package services;

import models.*;
import java.util.ArrayList;
import java.util.Iterator;

public class BookingService {

    // Create a booking → returns bookingId if success, else null
    public static String createBooking(String flightId, String username, String seat) {

        Flight f = FlightService.getById(flightId);
        if (f == null) return null;

        // Check seat availability
        if (!f.isSeatAvailable(seat)) return null;

        // Calculate dynamic price
        double price = PricingService.calculatePrice(f);

        // Book seat in flight object
        boolean ok = f.bookSeat(seat);
        if (!ok) return null;

        // Create booking entry
        String bookingId = IDGenerator.generate("BK");
        Booking bk = new Booking(bookingId, flightId, username, seat, price);

        DataStore.bookings.add(bk);

        // Save both booking + flight changes
        DataStore.saveBookings();
        DataStore.saveFlights();

        return bookingId;
    }


    // -------------------------------------------------------------------------
    // Passenger Cancel Booking  (username MUST match)
    // -------------------------------------------------------------------------
    public static boolean cancelBooking(String bookingId, String username) {

        Iterator<Booking> iter = DataStore.bookings.iterator();

        while (iter.hasNext()) {
            Booking b = iter.next();

            // Ensure passenger owns this booking
            if (b.getBookingId().equals(bookingId) && b.getUsername().equals(username)) {

                // Restore seat in flight
                Flight f = FlightService.getById(b.getFlightId());
                if (f != null) {
                    f.cancelSeat(b.getSeat());
                }

                // Remove booking record
                iter.remove();

                // Save changes
                DataStore.saveBookings();
                DataStore.saveFlights();

                return true;
            }
        }

        return false; // Not found or not owned
    }


    // -------------------------------------------------------------------------
    // Admin Cancel Booking (username NOT required)
    // -------------------------------------------------------------------------
    public static boolean adminCancelBooking(String bookingId) {

        Iterator<Booking> iter = DataStore.bookings.iterator();

        while (iter.hasNext()) {
            Booking b = iter.next();

            if (b.getBookingId().equals(bookingId)) {

                // Restore seat
                Flight f = FlightService.getById(b.getFlightId());
                if (f != null) {
                    f.cancelSeat(b.getSeat());
                }

                iter.remove();

                DataStore.saveBookings();
                DataStore.saveFlights();

                return true;
            }
        }
        return false;
    }


    // Get all bookings of a specific user
    public static ArrayList<Booking> getBookingsForUser(String username) {
        ArrayList<Booking> list = new ArrayList<>();
        for (Booking b : DataStore.bookings)
            if (b.getUsername().equals(username))
                list.add(b);
        return list;
    }


    // Admin: Get all bookings system-wide
    public static ArrayList<Booking> getAllBookings() {
        return new ArrayList<>(DataStore.bookings);
    }
}
