// -----------------------------------------------------------------------------
// FlightService.java
// Handles searching and retrieving flights
// Demonstrates: Streams, Lambda expressions, Collections
// -----------------------------------------------------------------------------
package services;

import models.*;

import java.util.*;
import java.util.stream.Collectors;

public class FlightService {

    // Search flights by source + destination
    public static ArrayList<Flight> search(String source, String destination) {

        return (ArrayList<Flight>) DataStore.flights.stream()
                .filter(f -> f.getSource().equalsIgnoreCase(source)
                        && f.getDestination().equalsIgnoreCase(destination))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    // Find flight by its ID
    public static Flight getById(String flightId) {
        for (Flight f : DataStore.flights)
            if (f.getFlightId().equals(flightId))
                return f;
        return null;
    }

    // Add a new flight (Admin)
    public static void addFlight(Flight f) {
        DataStore.flights.add(f);
        DataStore.saveFlights();
    }
}
