package services;

import models.Flight;

/**
 * Smart Fare Forecast Service
 * Predicts future pricing behavior for a given flight ID.
 */

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class FareForecastService {

    // Result object returned to GUI
    public static class ForecastResult {
        public final String flightId;
        public final double basePrice;
        public final List<Double> predictedPrices;
        public final String recommendation;

        public ForecastResult(String flightId, double basePrice, List<Double> predictedPrices, String recommendation) {
            this.flightId = flightId;
            this.basePrice = basePrice;
            this.predictedPrices = predictedPrices;
            this.recommendation = recommendation;
        }
    }

    private static final DecimalFormat MONEY = new DecimalFormat("0.00");

    /**
     * Forecast price behavior for next N days for a given flight.
     */
    public static ForecastResult forecastForNextDays(String flightId, int days) {

        if (flightId == null) flightId = "UNKNOWN";

        // 1) Try retrieving a real price from FlightService
        double basePrice = 500.0; // default fallback

        try {
            Flight f = FlightService.getById(flightId);   // import fixed
            if (f != null && f.getFare() > 0) {           // using existing method from earlier project
                basePrice = f.getFare();
            }
        } catch (Exception ignored) {
            // ignore if FlightService or Flight is missing
        }

        // 2) Deterministic seed from flightId
        int seed = Math.abs(flightId.hashCode() % 900);

        // 3) Price calculation loop
        List<Double> predicted = new ArrayList<>();

        for (int d = 1; d <= days; d++) {
            double season = Math.sin(d * 0.8) * 0.05;          // 5% oscillation
            double trend = (d - 1) * 0.01;                     // +1% per day
            double noise = (((seed * 31 + d * 17) % 100) - 50) / 1000.0;  // micro noise range

            double factor = 1 + season + trend + noise;
            double price = Math.max(50, basePrice * factor);

            price = Double.parseDouble(MONEY.format(price));
            predicted.add(price);
        }

        // 4) Recommendation logic
        double minPrice = Double.MAX_VALUE;
        int minIndex = -1;

        for (int i = 0; i < predicted.size(); i++) {
            if (predicted.get(i) < minPrice) {
                minPrice = predicted.get(i);
                minIndex = i;
            }
        }

        String recommendation;
        if (minPrice <= basePrice * 0.98 && minIndex > 0) {
            recommendation = "WAIT_" + (minIndex + 1) + "_DAYS";
        } else if (minPrice < basePrice) {
            recommendation = "WAIT_SHORT";
        } else {
            recommendation = "BUY_NOW";
        }

        return new ForecastResult(flightId, basePrice, predicted, recommendation);
    }

    /**
     * Generate nice readable forecast text for GUI.
     */
    public static String prettyPrintForecast(ForecastResult res) {

        StringBuilder sb = new StringBuilder();
        sb.append("📈 Smart Fare Forecast for Flight: ").append(res.flightId).append("\n\n");
        sb.append(String.format("Current Price: $%.2f\n\n", res.basePrice));
        sb.append("Predicted Next " + res.predictedPrices.size() + " Days:\n");

        for (int i = 0; i < res.predictedPrices.size(); i++) {
            sb.append(String.format(" Day +%d : $%.2f\n", i + 1, res.predictedPrices.get(i)));
        }

        sb.append("\nRecommended Action: ");

        switch (res.recommendation) {
            case "BUY_NOW":
                sb.append("Buy now — prices are expected to rise.");
                break;
            case "WAIT_SHORT":
                sb.append("Wait a little — small price drop expected.");
                break;
            default:
                if (res.recommendation.startsWith("WAIT_")) {
                    sb.append("Wait about " + res.recommendation.split("_")[1] + " days for best price.");
                } else {
                    sb.append("Monitor prices — no firm prediction.");
                }
        }

        sb.append("\n\nNote: This is a heuristic prediction only.");
        return sb.toString();
    }
}
