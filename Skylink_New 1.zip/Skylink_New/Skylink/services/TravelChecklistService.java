package services;

public class TravelChecklistService {

    public static String generateChecklist(String type) {

        StringBuilder checklist = new StringBuilder();

        checklist.append("🧳 TRAVEL CHECKLIST\n\n");

        if (type.equals("International")) {

            checklist.append("""
                    ✔ Passport
                    ✔ Visa Documents
                    ✔ Flight Tickets / Boarding Pass
                    ✔ Travel Insurance
                    ✔ Foreign Currency / Forex Card
                    ✔ International Power Adapter
                    ✔ Medicines & First Aid Kit
                    ✔ Hotel Booking Confirmation
                    ✔ Clothing (Weather Based)
                    ✔ Emergency Contact Sheet
                    ✔ Photocopies of Documents
                    """);

        } else { // Domestic
            checklist.append("""
                    ✔ ID Proof (Aadhaar / License / PAN)
                    ✔ Flight / Train Tickets
                    ✔ Wallet / Cards / Cash
                    ✔ Clothing (Weather Based)
                    ✔ Basic Medicines
                    ✔ Toiletries
                    ✔ Mobile Charger & Power Bank
                    ✔ Snacks & Water Bottle
                    ✔ Emergency Contacts
                    """);
        }

        return checklist.toString();
    }
}
