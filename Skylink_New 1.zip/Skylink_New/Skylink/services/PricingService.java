// -----------------------------------------------------------------------------
// PricingService.java
// Calculates dynamic flight price based on occupancy.
// Demonstrates: Simple logic + encapsulation + service layering
// -----------------------------------------------------------------------------
package services;

import models.*;

public class PricingService {

    public static double calculatePrice(Flight f) {

        int booked = f.getBookedSeats().size();
        int total = f.getTotalSeats();
        double base = f.getBasePrice();

        double occupancy = (double) booked / total;

        if (occupancy < 0.5)
            return base;                // Normal price

        else if (occupancy < 0.8)
            return base * 1.20;         // 20% increase

        else
            return base * 1.40;         // 40% increase
    }
}
