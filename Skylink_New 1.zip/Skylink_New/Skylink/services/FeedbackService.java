package services;

import models.Feedback;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;

/**
 * Feedback persistence & query service.
 * Stores lines in Skylink/data/feedbacks.txt
 */
public class FeedbackService {

    private static final String DATA_DIR = "Skylink/data/";
    private static final String FILE_PATH = DATA_DIR + "feedbacks.txt";

    private static void ensureDir() {
        File d = new File(DATA_DIR);
        if (!d.exists()) d.mkdirs();
    }

    /**
     * Submit a feedback. Returns generated feedbackId on success, null on failure.
     */
    public static synchronized String submitFeedback(String bookingId, String flightId,
                                                     String username, String category,
                                                     int rating, String comment) {
        if (username == null || username.trim().isEmpty()) return null;
        if (rating < 1) rating = 1;
        if (rating > 5) rating = 5;
        ensureDir();
        String feedbackId = "FB" + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase();
        Feedback f = new Feedback(feedbackId,
                bookingId == null ? "" : bookingId,
                flightId == null ? "" : flightId,
                username, category == null ? "General" : category, rating, comment == null ? "" : comment);
        try (FileOutputStream fos = new FileOutputStream(FILE_PATH, true);
             OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
             BufferedWriter bw = new BufferedWriter(osw)) {
            bw.write(f.toFileLine());
            bw.newLine();
            bw.flush();
            return feedbackId;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Read all feedbacks.
     */
    public static synchronized ArrayList<Feedback> readAll() {
        ArrayList<Feedback> out = new ArrayList<>();
        File f = new File(FILE_PATH);
        if (!f.exists()) return out;
        try (FileInputStream fis = new FileInputStream(f);
             InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
             BufferedReader br = new BufferedReader(isr)) {
            String line;
            while ((line = br.readLine()) != null) {
                Feedback fb = Feedback.fromFileLine(line);
                if (fb != null) out.add(fb);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return out;
    }

    /**
     * Get feedbacks by username.
     */
    public static ArrayList<Feedback> getByUser(String username) {
        ArrayList<Feedback> res = new ArrayList<>();
        for (Feedback f : readAll()) {
            if (f.getUsername().equals(username)) res.add(f);
        }
        return res;
    }

    /**
     * Get feedbacks for a flight ID.
     */
    public static ArrayList<Feedback> getByFlight(String flightId) {
        ArrayList<Feedback> res = new ArrayList<>();
        for (Feedback f : readAll()) {
            if (f.getFlightId() != null && f.getFlightId().equals(flightId)) res.add(f);
        }
        return res;
    }

    /**
     * Compute average rating for a flight. 0 if none.
     */
    public static double getAverageRatingForFlight(String flightId) {
        ArrayList<Feedback> list = getByFlight(flightId);
        if (list.isEmpty()) return 0.0;
        double sum = 0;
        for (Feedback f : list) sum += f.getRating();
        return sum / list.size();
    }
}

