package services;

import java.util.Random;

public class WeatherAlertService {

    public static String getWeatherAlert(String destination) {

        String[] conditions = {
                "Clear Sky – Safe for Travel",
                "Rain Expected – Carry Umbrella",
                "Thunderstorm Warning – Possible Delays",
                "Heavy Fog – Visibility Low",
                "Extreme Heat – Stay Hydrated",
                "Snowfall Expected – Dress Warm",
                "Strong Winds – Possible Turbulence",
                "Normal Weather – No alerts"
        };

        Random rand = new Random();
        int index = rand.nextInt(conditions.length);

        return "Weather at " + destination + ":\n\n" + conditions[index];
    }
}

