// -----------------------------------------------------------------------------
// IDGenerator.java
// Generates unique flight and booking IDs
// Demonstrates: Static methods, AtomicInteger
// -----------------------------------------------------------------------------
package services;

import models.*;

import java.util.concurrent.atomic.AtomicInteger;

public class IDGenerator {

    private static AtomicInteger fCounter = new AtomicInteger(100);
    private static AtomicInteger bCounter = new AtomicInteger(500);

    public static String generate(String prefix) {

        if (prefix.equals("FL"))
            return "FL" + fCounter.getAndIncrement();

        if (prefix.equals("BK"))
            return "BK" + bCounter.getAndIncrement();

        return prefix + System.currentTimeMillis();
    }
}
