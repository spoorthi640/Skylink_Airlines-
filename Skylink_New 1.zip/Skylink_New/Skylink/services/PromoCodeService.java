package services;

import java.util.HashMap;

public class PromoCodeService {

    private static HashMap<String, Integer> promoCodes = new HashMap<>();

    static {
        promoCodes.put("FLY50", 50);
        promoCodes.put("WELCOME10", 10);
        promoCodes.put("TRAVEL25", 25);
    }

    public static int validatePromo(String code) {
        return promoCodes.getOrDefault(code.toUpperCase(), -1);
    }

    public static double applyDiscount(double originalPrice, int discountPercent) {
        return originalPrice - (originalPrice * discountPercent / 100.0);
    }

    // ⭐ NEW FEATURE: Auto-apply the best promo code ⭐
    public static String getBestPromoCode() {
        String bestCode = "";
        int maxDiscount = 0;

        for (String code : promoCodes.keySet()) {
            int discount = promoCodes.get(code);
            if (discount > maxDiscount) {
                maxDiscount = discount;
                bestCode = code;
            }
        }
        return bestCode;
    }
}

