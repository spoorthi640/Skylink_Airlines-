package services;

import models.Booking;
import models.Flight;
import java.io.FileWriter;
import java.io.IOException;

public class ETicketService {

    public static String generateETicket(Booking booking) {

        Flight f = FlightService.getById(booking.getFlightId());

        String ticketText =
                "================ SKYLINK E-TICKET ================\n" +
                "Booking ID : " + booking.getBookingId() + "\n" +
                "Passenger  : " + booking.getUsername() + "\n" +
                "Flight ID  : " + booking.getFlightId() + "\n" +
                "From       : " + f.getSource() + "\n" +
                "To         : " + f.getDestination() + "\n" +
                "Date       : " + f.getDate() + "\n" +
                "Time       : " + f.getTime() + "\n" +
                "Seat       : " + booking.getSeat() + "\n" +
                "Price      : " + booking.getPrice() + "\n" +
                "===================================================\n" +
                "Thank you for booking with Skylink Airlines!\n";

        try {
            String path = "Skylink/data/etickets/";
            java.io.File dir = new java.io.File(path);
            if (!dir.exists()) dir.mkdirs();

            String fileName = path + booking.getBookingId() + "_ETicket.txt";

            FileWriter fw = new FileWriter(fileName);
            fw.write(ticketText);
            fw.close();

            return ticketText; // also return to show in popup

        } catch (IOException e) {
            e.printStackTrace();
            return "ERROR: Could not generate ticket.";
        }
    }
}
