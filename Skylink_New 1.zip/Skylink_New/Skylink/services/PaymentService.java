// -----------------------------------------------------------------------------
// PaymentService.java
// Simple simulated payment system
// Demonstrates: Multithreading, Randomization, Try-Catch
// -----------------------------------------------------------------------------
package services;

import models.*;

public class PaymentService {

    // Returns true = payment success, false = failed
    public static boolean processPayment(String username, double amount) {

        try {
            Thread.sleep(1500); // simulate processing delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 85% chance of success
        double r = Math.random();
        return r < 0.85;
    }
}
