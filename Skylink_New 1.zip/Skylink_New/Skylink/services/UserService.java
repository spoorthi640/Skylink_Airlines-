// -----------------------------------------------------------------------------
// UserService.java
// Handles login + registration logic
// Demonstrates: HashMap usage, basic validation, service pattern
// -----------------------------------------------------------------------------
package services;

import models.*;

public class UserService {

    // Register a new passenger
    public static boolean registerPassenger(String username, String password, String fullName) {

        // Check duplicate username
        if (DataStore.users.containsKey(username))
            return false;

        Passenger p = new Passenger(username, password, fullName);
        DataStore.users.put(username, p);
        DataStore.saveUsers();
        return true;
    }


    // Login method
    public static User login(String username, String password) {

        if (!DataStore.users.containsKey(username))
            return null;

        User u = DataStore.users.get(username);

        if (u.getPassword().equals(password))
            return u;

        return null;
    }
}
