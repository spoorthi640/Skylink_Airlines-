package services;

import models.SeatRating;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Service for storing and retrieving seat comfort ratings.
 * File storage: Skylink/data/seat_ratings.txt
 *
 * Methods:
 * - submitRating(...)   : append rating (returns true if success)
 * - getRatingsForFlight : list of SeatRating for a flight
 * - getRatingsByUser    : list of SeatRating by username
 * - getAverageRating    : average (double) for flight (or 0 if none)
 */
public class SeatRatingService {

    private static final String DATA_DIR = "Skylink/data/";
    private static final String FILE_PATH = DATA_DIR + "seat_ratings.txt";

    // Ensure data folder exists
    private static void ensureDataDir() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) dir.mkdirs();
    }

    /**
     * Submit a new rating. Returns true on success.
     */
    public static synchronized boolean submitRating(String flightId, String bookingId, String username, int rating, String comment) {
        if (flightId == null || username == null || rating < 1 || rating > 5) return false;
        ensureDataDir();
        SeatRating sr = new SeatRating(flightId, bookingId == null ? "" : bookingId, username, rating, comment == null ? "" : comment);
        try (FileOutputStream fos = new FileOutputStream(FILE_PATH, true);
             OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
             BufferedWriter bw = new BufferedWriter(osw)) {

            bw.write(sr.toFileLine());
            bw.newLine();
            bw.flush();
            return true;
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    /**
     * Read all ratings from storage.
     */
    public static synchronized ArrayList<SeatRating> readAllRatings() {
        ArrayList<SeatRating> out = new ArrayList<>();
        File f = new File(FILE_PATH);
        if (!f.exists()) return out;
        try (FileInputStream fis = new FileInputStream(f);
             InputStreamReader isr = new InputStreamReader(fis, StandardCharsets.UTF_8);
             BufferedReader br = new BufferedReader(isr)) {

            String line;
            while ((line = br.readLine()) != null) {
                SeatRating sr = SeatRating.fromFileLine(line);
                if (sr != null) out.add(sr);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return out;
    }

    /**
     * Get list of ratings for a specific flight.
     */
    public static ArrayList<SeatRating> getRatingsForFlight(String flightId) {
        ArrayList<SeatRating> out = new ArrayList<>();
        for (SeatRating s : readAllRatings()) {
            if (s.getFlightId().equals(flightId)) out.add(s);
        }
        return out;
    }

    /**
     * Get list of ratings by a user.
     */
    public static ArrayList<SeatRating> getRatingsByUser(String username) {
        ArrayList<SeatRating> out = new ArrayList<>();
        for (SeatRating s : readAllRatings()) {
            if (s.getUsername().equals(username)) out.add(s);
        }
        return out;
    }

    /**
     * Compute average rating for a flight. Returns 0 if no ratings.
     */
    public static double getAverageRating(String flightId) {
        ArrayList<SeatRating> list = getRatingsForFlight(flightId);
        if (list.isEmpty()) return 0.0;
        double sum = 0;
        for (SeatRating s : list) sum += s.getRating();
        return sum / list.size();
    }
}

