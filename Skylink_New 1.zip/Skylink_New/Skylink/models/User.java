// ---------------------------------------------
// User.java
// Abstract base class for all users
// Demonstrates: Abstraction, Encapsulation
// ---------------------------------------------
package models;

import java.io.Serializable;

public abstract class User implements Serializable {

    // Encapsulated fields
    protected String username;
    protected String password;
    protected String fullName;

    // Constructor
    public User(String username, String password, String fullName) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
    }

    // Getters (Encapsulation)
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getFullName() { return fullName; }
}
