// ---------------------------------------------
// Admin.java
// Inherits User class
// Used for admin dashboard and admin-only actions
// ---------------------------------------------
package models;

public class Admin extends User {

    public Admin(String username, String password, String fullName) {
        super(username, password, fullName);
    }

    @Override
    public String toString() {
        return "Admin: " + username + " | " + fullName;
    }
}
