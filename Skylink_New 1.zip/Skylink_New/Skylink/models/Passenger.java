// ---------------------------------------------
// Passenger.java
// Inherits User class
// Demonstrates: Inheritance
// ---------------------------------------------
package models;

public class Passenger extends User {

    public Passenger(String username, String password, String fullName) {
        super(username, password, fullName);  // calling parent constructor
    }

    @Override
    public String toString() {
        return "Passenger: " + username + " | " + fullName;
    }
}
