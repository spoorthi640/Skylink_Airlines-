// -----------------------------------------------------------
// Booking.java
// Represents one flight booking made by a passenger
// Demonstrates: Encapsulation, File storage helper methods
// -----------------------------------------------------------
package models;

public class Booking {

    private String bookingId;
    private String flightId;
    private String username;
    private String seat;
    private double price;

    public Booking(String bookingId, String flightId, String username, String seat, double price) {
        this.bookingId = bookingId;
        this.flightId = flightId;
        this.username = username;
        this.seat = seat;
        this.price = price;
    }

    // Getters
    public String getBookingId() { return bookingId; }
    public String getFlightId() { return flightId; }
    public String getUsername() { return username; }
    public String getSeat() { return seat; }
    public double getPrice() { return price; }

    // Convert to text line
    @Override
    public String toString() {
        return bookingId + "|" + flightId + "|" + username + "|" + seat + "|" + price;
    }

    // Convert from text line back to Booking object
    public static Booking fromString(String line) {
        String[] p = line.split("\\|");
        if (p.length < 5) return null;

        return new Booking(
            p[0], p[1], p[2], p[3],
            Double.parseDouble(p[4])
        );
    }
}
