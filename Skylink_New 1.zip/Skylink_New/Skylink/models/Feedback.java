package models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Feedback model.
 * Stored as a single line:
 * feedbackId|bookingId|flightId|username|category|rating|comment|timestamp
 */
public class Feedback {

    private String feedbackId;
    private String bookingId;   // may be blank if general feedback
    private String flightId;    // may be blank if general feedback
    private String username;
    private String category;    // e.g., "Service", "Cleanliness", "Food", "Other"
    private int rating;         // 1..5
    private String comment;
    private String timestamp;   // ISO string

    public Feedback(String feedbackId, String bookingId, String flightId, String username,
                    String category, int rating, String comment, String timestamp) {
        this.feedbackId = feedbackId;
        this.bookingId = bookingId;
        this.flightId = flightId;
        this.username = username;
        this.category = category;
        this.rating = rating;
        this.comment = comment;
        this.timestamp = timestamp;
    }

    public Feedback(String feedbackId, String bookingId, String flightId, String username,
                    String category, int rating, String comment) {
        this(feedbackId, bookingId, flightId, username, category, rating, comment,
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
    }

    public String getFeedbackId() { return feedbackId; }
    public String getBookingId() { return bookingId; }
    public String getFlightId() { return flightId; }
    public String getUsername() { return username; }
    public String getCategory() { return category; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }
    public String getTimestamp() { return timestamp; }

    /**
     * Serialize to a single line for file storage.
     * Pipes in comments are replaced with slashes, newlines removed.
     */
    public String toFileLine() {
        String safeComment = comment == null ? "" : comment.replace("\n", " ").replace("|", "/");
        String safeBooking = bookingId == null ? "" : bookingId;
        String safeFlight = flightId == null ? "" : flightId;
        String safeCategory = category == null ? "" : category.replace("|", "/");
        return feedbackId + "|" + safeBooking + "|" + safeFlight + "|" + username + "|" +
               safeCategory + "|" + rating + "|" + safeComment + "|" + timestamp;
    }

    /**
     * Parse a line from file into Feedback. Returns null on parse failure.
     */
    public static Feedback fromFileLine(String line) {
        if (line == null) return null;
        String[] p = line.split("\\|", -1);
        if (p.length < 8) return null;
        try {
            String fid = p[0];
            String bid = p[1];
            String flid = p[2];
            String user = p[3];
            String cat = p[4];
            int rate = Integer.parseInt(p[5]);
            String comm = p[6];
            String ts = p[7];
            return new Feedback(fid, bid, flid, user, cat, rate, comm, ts);
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "feedbackId='" + feedbackId + '\'' +
                ", bookingId='" + bookingId + '\'' +
                ", flightId='" + flightId + '\'' +
                ", username='" + username + '\'' +
                ", category='" + category + '\'' +
                ", rating=" + rating +
                ", comment='" + comment + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}

