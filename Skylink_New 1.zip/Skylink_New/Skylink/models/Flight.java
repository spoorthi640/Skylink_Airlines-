// -----------------------------------------------------------
// Flight.java
// Represents a flight in the system
// Demonstrates: Encapsulation, Collections, toString parsing
// -----------------------------------------------------------
package models;

import java.util.ArrayList;

public class Flight {

    private String flightId;
    private String source;
    private String destination;
    private String date;         // Simple String (YYYY-MM-DD)
    private String time;         // Simple String (HH:MM)
    private double basePrice;
    private int totalSeats;

    // List of already booked seats (for simple seat selection)
    private ArrayList<String> bookedSeats;

    public Flight(String flightId, String source, String destination,
                  String date, String time, double basePrice, int totalSeats) {

        this.flightId = flightId;
        this.source = source;
        this.destination = destination;
        this.date = date;
        this.time = time;
        this.basePrice = basePrice;
        this.totalSeats = totalSeats;
        this.bookedSeats = new ArrayList<>();
    }

    // -----------------------------
    // Getters
    // -----------------------------
    public String getFlightId() { return flightId; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public double getBasePrice() { return basePrice; }
    public int getTotalSeats() { return totalSeats; }
    public ArrayList<String> getBookedSeats() { return bookedSeats; }

    // Number of remaining seats
    public int getAvailableSeats() {
        return totalSeats - bookedSeats.size();
    }

    // Check if a seat is free
    public boolean isSeatAvailable(String seat) {
        return !bookedSeats.contains(seat);
    }

    // Book a seat if available
    public boolean bookSeat(String seat) {
        if (isSeatAvailable(seat)) {
            bookedSeats.add(seat);
            return true;
        }
        return false;
    }

    // Convert to file-friendly string
    @Override
    public String toString() {
        // Format: flightId|source|destination|date|time|basePrice|totalSeats|A1,A2
        StringBuilder sb = new StringBuilder();

        sb.append(flightId).append("|")
          .append(source).append("|")
          .append(destination).append("|")
          .append(date).append("|")
          .append(time).append("|")
          .append(basePrice).append("|")
          .append(totalSeats).append("|");

        // append booked seats
        for (int i = 0; i < bookedSeats.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(bookedSeats.get(i));
        }

        return sb.toString();
    }

    // Convert from file string back to Flight object
    public static Flight fromString(String line) {
        String[] p = line.split("\\|");
        if (p.length < 7) return null;

        Flight f = new Flight(
            p[0], p[1], p[2], p[3], p[4],
            Double.parseDouble(p[5]), Integer.parseInt(p[6])
        );

        // Load booked seats if any
        if (p.length >= 8 && !p[7].trim().isEmpty()) {
            String[] seats = p[7].split(",");
            for (String s : seats) f.bookedSeats.add(s);
        }

        return f;
    }

    public int getFare() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getFare'");
    }
}
