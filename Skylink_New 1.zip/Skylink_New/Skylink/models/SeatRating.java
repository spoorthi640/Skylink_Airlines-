package models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Simple model representing a seat comfort rating.
 * Stored on disk as a single line:
 * flightId|bookingId|username|rating|comment|timestamp
 */
public class SeatRating {

    private String flightId;
    private String bookingId;
    private String username;
    private int rating; // 1..5
    private String comment;
    private String timestamp; // ISO-ish string

    public SeatRating(String flightId, String bookingId, String username, int rating, String comment, String timestamp) {
        this.flightId = flightId;
        this.bookingId = bookingId;
        this.username = username;
        this.rating = rating;
        this.comment = comment;
        this.timestamp = timestamp;
    }

    public SeatRating(String flightId, String bookingId, String username, int rating, String comment) {
        this(flightId, bookingId, username, rating, comment,
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
    }

    public String getFlightId() {
        return flightId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getUsername() {
        return username;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public String getTimestamp() {
        return timestamp;
    }

    /**
     * Serializes a rating to a single-line text file format.
     */
    public String toFileLine() {
        String safeComment = (comment == null) ? "" : comment.replace("\n", " ").replace("|", "/");
        return flightId + "|" + bookingId + "|" + username + "|" + rating + "|" + safeComment + "|" + timestamp;
    }

    /**
     * Parse a file line into SeatRating. Returns null if parsing fails.
     */
    public static SeatRating fromFileLine(String line) {
        if (line == null) return null;
        String[] parts = line.split("\\|", -1);
        if (parts.length < 6) return null;
        try {
            String flightId = parts[0];
            String bookingId = parts[1];
            String username = parts[2];
            int rating = Integer.parseInt(parts[3]);
            String comment = parts[4];
            String ts = parts[5];
            return new SeatRating(flightId, bookingId, username, rating, comment, ts);
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public String toString() {
        return "SeatRating{" +
                "flightId='" + flightId + '\'' +
                ", bookingId='" + bookingId + '\'' +
                ", username='" + username + '\'' +
                ", rating=" + rating +
                ", comment='" + comment + '\'' +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}
