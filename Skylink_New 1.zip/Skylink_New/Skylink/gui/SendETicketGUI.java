// -----------------------------------------------------------------------------
// SendETicketGUI.java
// Lets passenger select a booking and generate an E-Ticket
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class SendETicketGUI extends JFrame {

    private static final String String = null;
    private String username;

    public SendETicketGUI(Passenger passenger) {

        this.username = passenger;

        setTitle("Send E-Ticket");
        setSize(650, 420);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lbl = new JLabel("Select a booking to send E-Ticket");
        lbl.setBounds(20, 10, 300, 25);
        add(lbl);

        // ---------------------
        // TABLE
        // ---------------------
        JTable table = new JTable();
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 40, 600, 260);
        add(pane);

        // Columns
        String[] cols = {"Booking ID", "Flight ID", "Seat", "Price"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);

        // Get user's bookings
        ArrayList<Booking> list = BookingService.getBookingsForUser(String);

        for (Booking b : list) {
            model.addRow(new Object[]{
                    b.getBookingId(),
                    b.getFlightId(),
                    b.getSeat(),
                    b.getPrice()
            });
        }

        table.setModel(model);

        // ---------------------
        // BUTTONS
        // ---------------------
        JButton btnSend = new JButton("Send E-Ticket");
        btnSend.setBounds(140, 320, 150, 30);
        add(btnSend);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(330, 320, 150, 30);
        add(btnBack);


        // ---------------------
        // EVENT HANDLING
        // ---------------------

        // SEND E-TICKET
        btnSend.addActionListener(e -> {

            int row = table.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a booking from the table!");
                return;
            }

            String bookingId = table.getValueAt(row, 0).toString();
            String flightId = table.getValueAt(row, 1).toString();
            String seat = table.getValueAt(row, 2).toString();
            double price = Double.parseDouble(table.getValueAt(row, 3).toString());

            Booking selectedBooking = new Booking(
                    bookingId,
                    flightId,
                    passenger,
                    seat,
                    price
            );

            // Generate E-Ticket
            String ticket = ETicketService.generateETicket(selectedBooking);

            // Popup
            JOptionPane.showMessageDialog(this,
                    "E-Ticket sent successfully!\n\n" + ticket,
                    "E-Ticket",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        // BACK BUTTON
        btnBack.addActionListener(e -> {
            dispose();
            new PassengerDashboard(new Passenger(String, "", "")); // Or fetch user properly
        });

        setVisible(true);
    }
}
