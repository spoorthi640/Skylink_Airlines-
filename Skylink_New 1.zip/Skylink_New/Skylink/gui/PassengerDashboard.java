package gui;

import models.Passenger;
import services.CancelBookingGUI;

import javax.swing.*;

public class PassengerDashboard extends JFrame {

    private Passenger passenger;

    public PassengerDashboard(Passenger passenger) {

        this.passenger = passenger;

        setTitle("Passenger Dashboard");
        setSize(650, 670); // Increased height for new Smart Fare Forecast
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblTitle = new JLabel("Welcome, " + passenger.getFullName() + "!");
        lblTitle.setBounds(240, 40, 300, 30);
        add(lblTitle);

        // -------------------------
        // BUTTONS
        // -------------------------
        JButton btnSearchFlights = new JButton("Search Flights");
        btnSearchFlights.setBounds(220, 100, 200, 35);
        add(btnSearchFlights);

        JButton btnMyBookings = new JButton("My Bookings");
        btnMyBookings.setBounds(220, 145, 200, 35);
        add(btnMyBookings);

        JButton btnSendETicket = new JButton("Send E-Ticket");
        btnSendETicket.setBounds(220, 190, 200, 35);
        add(btnSendETicket);

        JButton btnCancelBooking = new JButton("Cancel Booking");
        btnCancelBooking.setBounds(220, 235, 200, 35);
        add(btnCancelBooking);

        JButton btnTravelChecklist = new JButton("Travel Checklist");
        btnTravelChecklist.setBounds(220, 280, 200, 35);
        add(btnTravelChecklist);

        JButton btnSeatRating = new JButton("Seat Comfort Rating");
        btnSeatRating.setBounds(220, 325, 200, 35);
        add(btnSeatRating);

        JButton btnWeatherAlert = new JButton("Weather Alert Notification");
        btnWeatherAlert.setBounds(220, 370, 200, 35);
        add(btnWeatherAlert);

        JButton btnPromoCode = new JButton("Apply Promo Code");
        btnPromoCode.setBounds(220, 415, 200, 35);
        add(btnPromoCode);

        JButton btnFeedback = new JButton("Customer Feedback");
        btnFeedback.setBounds(220, 460, 200, 35);
        add(btnFeedback);

        // ⭐ New Feature: Smart Fare Forecast ⭐
        JButton btnFareForecast = new JButton("Smart Fare Forecast");
        btnFareForecast.setBounds(220, 505, 200, 35);
        add(btnFareForecast);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(220, 550, 200, 35);
        add(btnLogout);

        // -------------------------
        // ACTION LISTENERS
        // -------------------------
        btnSearchFlights.addActionListener(e -> {
            dispose();
            new SearchFlightsGUI(passenger);
        });

        btnMyBookings.addActionListener(e -> {
            dispose();
            new ViewBookingsGUI(passenger);
        });

        btnSendETicket.addActionListener(e -> {
            dispose();
            new SendETicketGUI(passenger);
        });

        btnCancelBooking.addActionListener(e -> {
            dispose();
            new CancelBookingGUI(false, passenger.getUsername());
        });

        btnTravelChecklist.addActionListener(e -> {
            dispose();
            new TravelChecklistGUI();
        });

        btnSeatRating.addActionListener(e -> {
            dispose();
            new SeatRatingGUI(passenger);
        });

        btnWeatherAlert.addActionListener(e -> {
            dispose();
            new WeatherAlertGUI(passenger);
        });

        btnPromoCode.addActionListener(e -> {
            dispose();
            new PromoDiscountGUI(passenger, 500.00); // example price
        });

        btnFeedback.addActionListener(e -> {
            dispose();
            new FeedbackGUI(passenger);
        });

        btnFareForecast.addActionListener(e -> {
            dispose();
            new FareForecastGUI(passenger);
        });

        btnLogout.addActionListener(e -> {
            dispose();
            new LoginGUI();
        });

        setVisible(true);
    }
}
