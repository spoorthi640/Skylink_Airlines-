package gui;

import models.Passenger;
import services.PromoCodeService;

import javax.swing.*;

public class PromoDiscountGUI extends JFrame {

    public PromoDiscountGUI(Passenger passenger, double originalPrice) {

        setTitle("Apply Promo Discount");
        setSize(450, 260);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lblOriginal = new JLabel("Original Ticket Price: $" + originalPrice);
        lblOriginal.setBounds(100, 40, 300, 30);
        add(lblOriginal);

        JButton btnApplyPromo = new JButton("Apply Best Promo");
        btnApplyPromo.setBounds(140, 130, 160, 40);
        add(btnApplyPromo);

        btnApplyPromo.addActionListener(e -> {
            String bestCode = PromoCodeService.getBestPromoCode();
            int discount = PromoCodeService.validatePromo(bestCode);
            double finalAmount = PromoCodeService.applyDiscount(originalPrice, discount);

            JOptionPane.showMessageDialog(null,
                    "Best Promo Applied: " + bestCode +
                    "\nDiscount: " + discount + "%" +
                    "\nFinal Price: $" + finalAmount,
                    "Promo Applied Successfully", JOptionPane.INFORMATION_MESSAGE);

            dispose();   // Close window after applying promo
        });

        setVisible(true);
    }
}

