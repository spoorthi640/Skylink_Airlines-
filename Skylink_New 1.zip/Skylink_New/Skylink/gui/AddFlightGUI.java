// -----------------------------------------------------------------------------
// AddFlightGUI.java
// Admin can add new flights to the system
// Demonstrates: CRUD operations, File saving, GUI forms
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;

public class AddFlightGUI extends JFrame {

    private JTextField idField, srcField, destField, dateField, timeField, priceField, seatsField;
    private Admin admin;

    public AddFlightGUI(Admin a) {

        this.admin = a;

        setTitle("Add New Flight");
        setSize(450, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel l;

        l = new JLabel("Flight ID:");
        l.setBounds(30, 30, 100, 25);
        add(l);

        idField = new JTextField(IDGenerator.generate("FL"));
        idField.setBounds(150, 30, 240, 25);
        add(idField);

        l = new JLabel("Source:");
        l.setBounds(30, 70, 100, 25);
        add(l);

        srcField = new JTextField();
        srcField.setBounds(150, 70, 240, 25);
        add(srcField);

        l = new JLabel("Destination:");
        l.setBounds(30, 110, 100, 25);
        add(l);

        destField = new JTextField();
        destField.setBounds(150, 110, 240, 25);
        add(destField);

        l = new JLabel("Date (YYYY-MM-DD):");
        l.setBounds(30, 150, 150, 25);
        add(l);

        dateField = new JTextField();
        dateField.setBounds(200, 150, 190, 25);
        add(dateField);

        l = new JLabel("Time (HH:MM):");
        l.setBounds(30, 190, 150, 25);
        add(l);

        timeField = new JTextField();
        timeField.setBounds(150, 190, 240, 25);
        add(timeField);

        l = new JLabel("Base Price:");
        l.setBounds(30, 230, 100, 25);
        add(l);

        priceField = new JTextField();
        priceField.setBounds(150, 230, 240, 25);
        add(priceField);

        l = new JLabel("Total Seats:");
        l.setBounds(30, 270, 100, 25);
        add(l);

        seatsField = new JTextField();
        seatsField.setBounds(150, 270, 240, 25);
        add(seatsField);

        JButton btnAdd = new JButton("Save Flight");
        btnAdd.setBounds(150, 310, 130, 30);
        add(btnAdd);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(290, 310, 100, 30);
        add(btnBack);

        btnAdd.addActionListener(e -> saveFlight());

        btnBack.addActionListener(e -> {
            dispose();
            new AdminDashboard(admin);
        });

        setVisible(true);
    }

    private void saveFlight() {

        try {
            String id = idField.getText().trim();
            String src = srcField.getText().trim();
            String dst = destField.getText().trim();
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            double price = Double.parseDouble(priceField.getText().trim());
            int seats = Integer.parseInt(seatsField.getText().trim());

            Flight f = new Flight(id, src, dst, date, time, price, seats);

            FlightService.addFlight(f);

            JOptionPane.showMessageDialog(this, "Flight Added Successfully!");

            dispose();
            new AdminDashboard(admin);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input!");
        }
    }
}
