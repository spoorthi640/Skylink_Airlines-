// -----------------------------------------------------------------------------
// PaymentGUI.java
// Handles simulated payment and final booking creation
// Demonstrates: Multithreading (sleep), randomization, service linking
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;

public class PaymentGUI extends JFrame {

    private Passenger passenger;
    private String flightId;
    private String seat;

    public PaymentGUI(Passenger p, String flightId, String seat) {

        this.passenger = p;
        this.flightId = flightId;
        this.seat = seat;

        setTitle("Payment");
        setSize(350, 220);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel l1 = new JLabel("Processing Payment...");
        l1.setBounds(80, 40, 200, 25);
        add(l1);

        JButton btnPay = new JButton("Confirm Payment");
        btnPay.setBounds(90, 90, 160, 30);
        add(btnPay);

        btnPay.addActionListener(e -> processPayment());

        setVisible(true);
    }

    private void processPayment() {

        Flight f = FlightService.getById(flightId);
        double price = PricingService.calculatePrice(f);

        // Simulate payment
        boolean success = PaymentService.processPayment(passenger.getUsername(), price);

        if (!success) {
            JOptionPane.showMessageDialog(this, "Payment Failed! Try again.");
            return;
        }

        // Create booking if payment is successful
        String bookingId = BookingService.createBooking(flightId, passenger.getUsername(), seat);

        JOptionPane.showMessageDialog(this,
                "Payment Successful!\nBooking ID: " + bookingId);

        dispose();
        new PassengerDashboard(passenger);
    }
}
