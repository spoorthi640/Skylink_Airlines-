// -----------------------------------------------------------------------------
// ViewBookingsGUI.java
// Shows user's bookings or ALL bookings (if admin)
// Demonstrates: Polymorphism, table rendering + E-Ticket Feature
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class ViewBookingsGUI extends JFrame {

    public ViewBookingsGUI(User user) {

        setTitle("View Bookings");
        setSize(650, 450);
        setLayout(null);
        setLocationRelativeTo(null);

        JTable table = new JTable();
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 20, 600, 260);
        add(pane);

        // --------------------------
        // SEND E-TICKET BUTTON
        // --------------------------
        JButton btnETicket = new JButton("Send E-Ticket");
        btnETicket.setBounds(120, 300, 150, 30);
        add(btnETicket);

        btnETicket.addActionListener(e -> {

            int row = table.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a booking from the table first!");
                return;
            }

            // Extract booking data
            String bookingId = table.getValueAt(row, 0).toString();
            String flightId = table.getValueAt(row, 1).toString();
            String username = table.getValueAt(row, 2).toString();
            String seat = table.getValueAt(row, 3).toString();
            double price = Double.parseDouble(table.getValueAt(row, 4).toString());

            // Create Booking object
            Booking b = new Booking(bookingId, flightId, username, seat, price);

            // Generate E-ticket
            String ticket = ETicketService.generateETicket(b);

            // Popup message
            JOptionPane.showMessageDialog(this,
                    "E-Ticket generated successfully!\n\n" + ticket,
                    "E-Ticket",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        // --------------------------
        // BACK BUTTON
        // --------------------------
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(350, 300, 150, 30);
        add(btnBack);

        btnBack.addActionListener(e -> {
            dispose();
            if (user instanceof Passenger)
                new PassengerDashboard((Passenger) user);
            else
                new AdminDashboard((Admin) user);
        });

        // Table columns
        String[] cols = {"Booking ID", "Flight ID", "Username", "Seat", "Price"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);

        ArrayList<Booking> list;

        if (user instanceof Passenger)
            list = BookingService.getBookingsForUser(user.getUsername());
        else
            list = BookingService.getAllBookings();

        for (Booking b : list) {
            model.addRow(new Object[]{
                    b.getBookingId(),
                    b.getFlightId(),
                    b.getUsername(),
                    b.getSeat(),
                    b.getPrice()
            });
        }

        table.setModel(model);

        setVisible(true);
    }
}
