// -----------------------------------------------------------------------------
// BookingGUI.java
// Lets user choose a seat and proceed to payment
// Demonstrates: Simple seat selection, dynamic price display
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;
import java.util.ArrayList;

public class BookingGUI extends JFrame {

    private Passenger passenger;
    private String flightId;

    private JComboBox<String> seatBox;
    private JLabel priceLabel;

    public BookingGUI(Passenger p, String flightId) {

        this.passenger = p;
        this.flightId = flightId;

        setTitle("Select Seat & Book");
        setSize(400, 300);
        setLayout(null);
        setLocationRelativeTo(null);

        Flight f = FlightService.getById(flightId);

        JLabel info = new JLabel("Flight: " + f.getFlightId() + " | " + f.getSource() + " → " + f.getDestination());
        info.setBounds(20, 20, 350, 25);
        add(info);

        // Seat selection label + dropdown
        JLabel seatLabel = new JLabel("Select Seat:");
        seatLabel.setBounds(20, 70, 100, 25);
        add(seatLabel);

        seatBox = new JComboBox<>();
        seatBox.setBounds(120, 70, 200, 25);
        add(seatBox);

        // Fill dropdown with AVAILABLE seats only
        fillAvailableSeats(f);

        // Show dynamic calculated price
        JLabel pLabel = new JLabel("Ticket Price:");
        pLabel.setBounds(20, 120, 100, 25);
        add(pLabel);

        double price = PricingService.calculatePrice(f);
        priceLabel = new JLabel("₹ " + price);
        priceLabel.setBounds(120, 120, 200, 25);
        add(priceLabel);

        // Book button
        JButton btnPay = new JButton("Proceed to Payment");
        btnPay.setBounds(80, 170, 200, 30);
        add(btnPay);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(140, 215, 120, 30);
        add(btnBack);

        btnPay.addActionListener(e -> {
            String seat = seatBox.getSelectedItem().toString();
            dispose();
            new PaymentGUI(passenger, flightId, seat);
        });

        btnBack.addActionListener(e -> {
            dispose();
            new SearchFlightsGUI(passenger);
        });

        setVisible(true);
    }

    // Load all free seats
    private void fillAvailableSeats(Flight f) {

        ArrayList<String> booked = f.getBookedSeats();

        // For simplicity: seats A1–A30
        for (int i = 1; i <= f.getTotalSeats(); i++) {
            String seat = "A" + i;
            if (!booked.contains(seat)) {
                seatBox.addItem(seat);
            }
        }
    }
}
