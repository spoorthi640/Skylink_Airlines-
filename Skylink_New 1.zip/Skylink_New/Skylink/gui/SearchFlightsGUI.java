// -----------------------------------------------------------------------------
// SearchFlightsGUI.java
// Passenger searches for flights by source + destination
// Demonstrates: GUI tables, event handling, linking services to UI
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class SearchFlightsGUI extends JFrame {

    private Passenger passenger;
    private JTextField srcField, destField;
    private JTable table;

    public SearchFlightsGUI(Passenger p) {

        this.passenger = p;

        setTitle("Search Flights - Skylink");
        setSize(650, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        // Labels & fields
        JLabel l1 = new JLabel("Source:");
        l1.setBounds(30, 20, 80, 25);
        add(l1);

        srcField = new JTextField();
        srcField.setBounds(100, 20, 200, 25);
        add(srcField);

        JLabel l2 = new JLabel("Destination:");
        l2.setBounds(320, 20, 100, 25);
        add(l2);

        destField = new JTextField();
        destField.setBounds(420, 20, 180, 25);
        add(destField);

        // Search button
        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(260, 60, 120, 30);
        add(btnSearch);

        // Table to show flights
        table = new JTable();
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(30, 110, 570, 180);
        add(pane);

        // Book button
        JButton btnBook = new JButton("Book Selected Flight");
        btnBook.setBounds(200, 310, 220, 30);
        add(btnBook);

        // Back button
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(440, 310, 120, 30);
        add(btnBack);

        // Search action
        btnSearch.addActionListener(e -> doSearch());

        // Book action
        btnBook.addActionListener(e -> doBook());

        // Back
        btnBack.addActionListener(e -> {
            dispose();
            new PassengerDashboard(passenger);
        });

        setVisible(true);
    }

    // Perform search
    private void doSearch() {

        String src = srcField.getText().trim();
        String dest = destField.getText().trim();

        if (src.isEmpty() || dest.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both source and destination.");
            return;
        }

        ArrayList<Flight> results = FlightService.search(src, dest);

        if (results.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No flights found.");
        }

        // Fill table
        String[] cols = {"Flight ID", "Date", "Time", "Price (Base)", "Available Seats"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);

        for (Flight f : results) {
            model.addRow(new Object[]{
                    f.getFlightId(),
                    f.getDate(),
                    f.getTime(),
                    f.getBasePrice(),
                    f.getAvailableSeats()
            });
        }

        table.setModel(model);
    }

    // Book selected row
    private void doBook() {

        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a flight first.");
            return;
        }

        String flightId = table.getValueAt(row, 0).toString();

        dispose();
        new BookingGUI(passenger, flightId);
    }
}
