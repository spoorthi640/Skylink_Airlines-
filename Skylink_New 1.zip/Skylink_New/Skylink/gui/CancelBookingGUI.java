package services;

import javax.swing.*;

import gui.SendETicketGUI;

import java.awt.*;

public class CancelBookingGUI extends JFrame {

    public CancelBookingGUI(boolean isAdmin, String username) {

        setTitle("Cancel Booking");
        setSize(430, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl = new JLabel("Enter Booking ID to Cancel:");
        lbl.setBounds(30, 20, 300, 25);
        add(lbl);

        JTextField bookingField = new JTextField();
        bookingField.setBounds(30, 55, 350, 30);
        add(bookingField);

        JButton cancelBtn = new JButton("Cancel Booking");
        cancelBtn.setBounds(120, 100, 160, 35);
        add(cancelBtn);

        JLabel status = new JLabel("", SwingConstants.CENTER);
        status.setBounds(20, 145, 380, 30);
        status.setForeground(Color.RED);
        add(status);

        JButton sendReceiptBtn = new JButton("Send Cancellation E-Ticket");
        sendReceiptBtn.setBounds(90, 180, 230, 35);
        sendReceiptBtn.setEnabled(false);   // enabled after success
        add(sendReceiptBtn);

        // -----------------------------------------
        // CANCEL BUTTON EVENT
        // -----------------------------------------
        cancelBtn.addActionListener(e -> {

            String bookingId = bookingField.getText().trim();

            if (bookingId.isEmpty()) {
                status.setText("Please enter a booking ID.");
                return;
            }

            // Optional simple validation
            if (!bookingId.matches("[A-Za-z0-9_-]+")) {
                status.setText("Invalid booking ID format!");
                return;
            }

            // Confirmation dialog
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to cancel Booking ID: " + bookingId + "?",
                    "Confirm Cancellation",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm != JOptionPane.YES_OPTION)
                return;

            // Perform cancel
            boolean success;
            if (isAdmin) {
                success = BookingService.adminCancelBooking(bookingId);
            } else {
                success = BookingService.cancelBooking(bookingId, username);
            }

            if (success) {
                status.setForeground(new Color(0, 128, 0));
                status.setText("Booking cancelled successfully!");

                // Enable E-ticket button
                sendReceiptBtn.setEnabled(true);

            } else {
                status.setForeground(Color.RED);
                status.setText("Invalid or unauthorized booking ID!");
            }
        });

        // -----------------------------------------
        // SEND CANCEL E-TICKET BUTTON EVENT
        // -----------------------------------------
        sendReceiptBtn.addActionListener(e -> {
            String bookingId = bookingField.getText().trim();
            new SendETicketGUI(bookingId);   // open your e-ticket window
        });

        setVisible(true);
    }
}
