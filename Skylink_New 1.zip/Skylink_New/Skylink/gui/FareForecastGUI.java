package gui;

import models.Booking;
import models.Passenger;
import services.BookingService;
import services.FareForecastService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

/**
 * GUI for Smart Fare Forecast.
 * Usage:
 *    new FareForecastGUI(passenger);
 *
 * Lists passenger bookings (flight IDs). Select one and click "Show Forecast".
 */
public class FareForecastGUI extends JFrame {

    private Passenger passenger;
    private JTable table;
    private DefaultTableModel model;
    private JTextArea outputArea;

    public FareForecastGUI(Passenger passenger) {
        this.passenger = passenger;

        setTitle("Smart Fare Forecast");
        setSize(760, 520);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel hdr = new JLabel("Select a booking (flight) to view fare forecast");
        hdr.setBounds(20, 10, 400, 25);
        add(hdr);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 40, 700, 200);
        add(sp);

        model = new DefaultTableModel(new String[]{"Booking ID", "Flight ID", "Seat", "Price"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table.setModel(model);
        loadBookings();

        JButton btnForecast = new JButton("Show Forecast");
        btnForecast.setBounds(120, 260, 160, 35);
        add(btnForecast);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(300, 260, 120, 35);
        add(btnBack);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane outSp = new JScrollPane(outputArea);
        outSp.setBounds(20, 310, 700, 170);
        add(outSp);

        // Actions
        btnForecast.addActionListener(e -> onShowForecast());
        btnBack.addActionListener(e -> {
            dispose();
            new PassengerDashboard(passenger);
        });

        setVisible(true);
    }

    private void loadBookings() {
        model.setRowCount(0);
        ArrayList<Booking> list = BookingService.getBookingsForUser(passenger.getUsername());
        for (Booking b : list) {
            model.addRow(new Object[]{
                    b.getBookingId(),
                    b.getFlightId(),
                    b.getSeat(),
                    b.getPrice()
            });
        }
    }

    private void onShowForecast() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking (flight) first!");
            return;
        }

        String flightId = table.getValueAt(row, 1).toString();

        FareForecastService.ForecastResult result =
                FareForecastService.forecastForNextDays(flightId, 7);

        String formatted = FareForecastService.prettyPrintForecast(result);
        outputArea.setText(formatted);
    }
}
