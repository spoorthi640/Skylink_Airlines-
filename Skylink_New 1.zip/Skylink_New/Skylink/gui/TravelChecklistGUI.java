package gui;

import services.TravelChecklistService;

import javax.swing.*;
import java.awt.*;

public class TravelChecklistGUI extends JFrame {

    public TravelChecklistGUI() {

        setTitle("Travel Checklist Generator");
        setSize(500, 500);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Generate Travel Checklist", SwingConstants.CENTER);
        title.setBounds(120, 20, 250, 30);
        add(title);

        String[] tripOptions = {"Domestic", "International"};
        JComboBox<String> combo = new JComboBox<>(tripOptions);
        combo.setBounds(170, 70, 150, 30);
        add(combo);

        JButton generateBtn = new JButton("Generate Checklist");
        generateBtn.setBounds(160, 120, 180, 35);
        add(generateBtn);

        JTextArea resultArea = new JTextArea();
        resultArea.setBounds(50, 180, 390, 250);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Arial", Font.PLAIN, 14));
        add(resultArea);

        generateBtn.addActionListener(e -> {
            String type = combo.getSelectedItem().toString();
            String output = TravelChecklistService.generateChecklist(type);
            resultArea.setText(output);
        });

        setVisible(true);
    }
}
