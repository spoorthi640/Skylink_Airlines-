package gui;

import models.Booking;
import models.Passenger;
import services.BookingService;
import services.SeatRatingService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

/**
 * GUI that lets a passenger rate seat comfort for one of their bookings.
 *
 * Usage: new SeatRatingGUI(passenger);
 */
public class SeatRatingGUI extends JFrame {

    private Passenger passenger;
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<Integer> ratingCombo;
    private JTextArea commentArea;
    private JLabel avgLabel;

    public SeatRatingGUI(Passenger passenger) {
        this.passenger = passenger;

        setTitle("Seat Comfort Rating");
        setSize(760, 520);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbl = new JLabel("Select a booking and rate seat comfort (1-5)");
        lbl.setBounds(20, 10, 500, 25);
        add(lbl);

        // Table of user's bookings
        table = new JTable();
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 40, 700, 200);
        add(pane);

        String[] cols = {"Booking ID", "Flight ID", "Seat", "Price"};
        model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table.setModel(model);

        // Load bookings
        loadBookings();

        // rating controls
        JLabel lblRating = new JLabel("Rating (1-5):");
        lblRating.setBounds(20, 260, 100, 25);
        add(lblRating);

        ratingCombo = new JComboBox<>(new Integer[]{1,2,3,4,5});
        ratingCombo.setBounds(120, 260, 60, 25);
        add(ratingCombo);

        JLabel lblComment = new JLabel("Comment:");
        lblComment.setBounds(20, 300, 100, 25);
        add(lblComment);

        commentArea = new JTextArea();
        JScrollPane commentPane = new JScrollPane(commentArea);
        commentPane.setBounds(120, 300, 600, 100);
        add(commentPane);

        JButton btnSubmit = new JButton("Submit Rating");
        btnSubmit.setBounds(120, 420, 140, 35);
        add(btnSubmit);

        avgLabel = new JLabel("Average rating: -");
        avgLabel.setBounds(300, 260, 300, 25);
        add(avgLabel);

        JButton btnRefreshAvg = new JButton("Refresh Average");
        btnRefreshAvg.setBounds(300, 290, 150, 25);
        add(btnRefreshAvg);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(600, 420, 120, 35);
        add(btnBack);

        // events
        btnSubmit.addActionListener(e -> doSubmit());
        btnRefreshAvg.addActionListener(e -> refreshAverageForSelectedFlight());
        btnBack.addActionListener(e -> {
            dispose();
            new PassengerDashboard(passenger);
        });

        // update average when table selection changes
        table.getSelectionModel().addListSelectionListener(e -> refreshAverageForSelectedFlight());

        setVisible(true);
    }

    private void loadBookings() {
        model.setRowCount(0);
        ArrayList<Booking> list = BookingService.getBookingsForUser(passenger.getUsername());
        for (Booking b : list) {
            model.addRow(new Object[]{
                    b.getBookingId(),
                    b.getFlightId(),
                    b.getSeat(),
                    b.getPrice()
            });
        }
    }

    private void doSubmit() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a booking to rate.");
            return;
        }
        String bookingId = table.getValueAt(row, 0).toString();
        String flightId = table.getValueAt(row, 1).toString();
        int rating = (Integer) ratingCombo.getSelectedItem();
        String comment = commentArea.getText().trim();

        boolean ok = SeatRatingService.submitRating(flightId, bookingId, passenger.getUsername(), rating, comment);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Thank you! Your rating has been recorded.");
            commentArea.setText("");
            refreshAverageForSelectedFlight();
        } else {
            JOptionPane.showMessageDialog(this, "Could not save rating. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshAverageForSelectedFlight() {
        int row = table.getSelectedRow();
        if (row == -1) {
            avgLabel.setText("Average rating: -");
            return;
        }
        String flightId = table.getValueAt(row, 1).toString();
        double avg = SeatRatingService.getAverageRating(flightId);
        if (avg <= 0) {
            avgLabel.setText("Average rating: no ratings yet");
        } else {
            avgLabel.setText(String.format("Average rating for flight %s: %.2f / 5.0", flightId, avg));
        }
    }
}

