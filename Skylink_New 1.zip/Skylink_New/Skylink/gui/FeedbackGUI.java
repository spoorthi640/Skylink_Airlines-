package gui;

import models.Booking;
import models.Feedback;
import models.Passenger;
import services.BookingService;
import services.FeedbackService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * Passenger feedback submission GUI.
 * Usage: new FeedbackGUI(passenger);
 */
public class FeedbackGUI extends JFrame {

    private Passenger passenger;
    private JTable bookingTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> categoryCombo;
    private JComboBox<Integer> ratingCombo;
    private JTextArea commentArea;
    private JTable viewFeedbackTable;
    private DefaultTableModel viewModel;

    public FeedbackGUI(Passenger passenger) {
        this.passenger = passenger;
        setTitle("Customer Feedback");
        setSize(900, 600);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbl = new JLabel("Submit Feedback (optional: select booking)");
        lbl.setBounds(20, 10, 400, 25);
        add(lbl);

        // Bookings table (optional tie)
        bookingTable = new JTable();
        JScrollPane p1 = new JScrollPane(bookingTable);
        p1.setBounds(20, 40, 540, 180);
        add(p1);

        tableModel = new DefaultTableModel(new String[]{"Booking ID", "Flight ID", "Seat", "Price"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        bookingTable.setModel(tableModel);
        loadBookings();

        // Feedback controls
        JLabel lblCat = new JLabel("Category:");
        lblCat.setBounds(580, 40, 80, 25);
        add(lblCat);

        categoryCombo = new JComboBox<>(new String[]{"Service", "Cleanliness", "Food", "Seats", "Other"});
        categoryCombo.setBounds(660, 40, 200, 25);
        add(categoryCombo);

        JLabel lblRating = new JLabel("Rating:");
        lblRating.setBounds(580, 80, 80, 25);
        add(lblRating);

        ratingCombo = new JComboBox<>(new Integer[]{1,2,3,4,5});
        ratingCombo.setBounds(660, 80, 80, 25);
        add(ratingCombo);

        JLabel lblComment = new JLabel("Comment:");
        lblComment.setBounds(580, 120, 80, 25);
        add(lblComment);

        commentArea = new JTextArea();
        JScrollPane p2 = new JScrollPane(commentArea);
        p2.setBounds(580, 150, 300, 150);
        add(p2);

        JButton btnSubmit = new JButton("Submit Feedback");
        btnSubmit.setBounds(580, 320, 180, 35);
        add(btnSubmit);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(780, 320, 100, 35);
        add(btnBack);

        // Section to view user's feedbacks
        JLabel lblYour = new JLabel("Your Feedbacks / My Submissions");
        lblYour.setBounds(20, 240, 400, 25);
        add(lblYour);

        viewFeedbackTable = new JTable();
        JScrollPane p3 = new JScrollPane(viewFeedbackTable);
        p3.setBounds(20, 270, 860, 260);
        add(p3);

        viewModel = new DefaultTableModel(new String[]{"FID","BookingID","FlightID","Category","Rating","Comment","Time"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        viewFeedbackTable.setModel(viewModel);
        loadUserFeedbacks();

        // Actions
        btnSubmit.addActionListener(e -> onSubmit());
        btnBack.addActionListener(e -> {
            dispose();
            new PassengerDashboard(passenger);
        });

        setVisible(true);
    }

    private void loadBookings() {
        tableModel.setRowCount(0);
        ArrayList<Booking> list = BookingService.getBookingsForUser(passenger.getUsername());
        for (Booking b : list) {
            tableModel.addRow(new Object[]{b.getBookingId(), b.getFlightId(), b.getSeat(), b.getPrice()});
        }
    }

    private void loadUserFeedbacks() {
        viewModel.setRowCount(0);
        ArrayList<Feedback> list = FeedbackService.getByUser(passenger.getUsername());
        for (Feedback f : list) {
            viewModel.addRow(new Object[]{
                    f.getFeedbackId(),
                    f.getBookingId(),
                    f.getFlightId(),
                    f.getCategory(),
                    f.getRating(),
                    f.getComment(),
                    f.getTimestamp()
            });
        }
    }

    private void onSubmit() {
        String bookingId = "";
        String flightId = "";

        int sel = bookingTable.getSelectedRow();
        if (sel != -1) {
            bookingId = bookingTable.getValueAt(sel, 0).toString();
            flightId = bookingTable.getValueAt(sel, 1).toString();
        }

        String category = categoryCombo.getSelectedItem().toString();
        int rating = (Integer) ratingCombo.getSelectedItem();
        String comment = commentArea.getText().trim();

        String fid = FeedbackService.submitFeedback(bookingId, flightId, passenger.getUsername(), category, rating, comment);
        if (fid != null) {
            JOptionPane.showMessageDialog(this, "Thanks! Feedback submitted (ID: " + fid + ").");
            commentArea.setText("");
            loadUserFeedbacks();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to submit feedback.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

