// -----------------------------------------------------------------------------
// RegisterGUI.java
// Passenger registration window
// Demonstrates: Swing forms, event handling
// -----------------------------------------------------------------------------
package gui;

import services.*;

import javax.swing.*;

public class RegisterGUI extends JFrame {

    private JTextField nameField, userField;
    private JPasswordField passField;

    public RegisterGUI() {

        setTitle("Skylink - Register");
        setSize(420, 260);
        setLayout(null);
        setLocationRelativeTo(null);

        // Full name
        JLabel l1 = new JLabel("Full Name:");
        l1.setBounds(30, 20, 100, 25);
        add(l1);

        nameField = new JTextField();
        nameField.setBounds(130, 20, 240, 25);
        add(nameField);

        // Username
        JLabel l2 = new JLabel("Username:");
        l2.setBounds(30, 60, 100, 25);
        add(l2);

        userField = new JTextField();
        userField.setBounds(130, 60, 240, 25);
        add(userField);

        // Password
        JLabel l3 = new JLabel("Password:");
        l3.setBounds(30, 100, 100, 25);
        add(l3);

        passField = new JPasswordField();
        passField.setBounds(130, 100, 240, 25);
        add(passField);

        // Register button
        JButton btnReg = new JButton("Register");
        btnReg.setBounds(130, 150, 120, 30);
        add(btnReg);

        // Back button
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(260, 150, 110, 30);
        add(btnBack);

        // Register action
        btnReg.addActionListener(e -> doRegister());

        // Back → go to login
        btnBack.addActionListener(e -> {
            dispose();
            new LoginGUI();
        });

        setVisible(true);
    }

    private void doRegister() {

        String fullName = nameField.getText().trim();
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();

        if (fullName.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill all fields.");
            return;
        }

        boolean ok = UserService.registerPassenger(username, password, fullName);

        if (!ok) {
            JOptionPane.showMessageDialog(this, "Username already exists.");
            return;
        }

        JOptionPane.showMessageDialog(this, "Registration successful! Please login.");

        dispose();
        new LoginGUI();
    }
}
