// -----------------------------------------------------------------------------
// LoginGUI.java
// Main login window for both Admin & Passenger
// Demonstrates: Swing GUI, Event Handling, Integration with UserService
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;

public class LoginGUI extends JFrame {

    private JTextField userField;
    private JPasswordField passField;

    public LoginGUI() {

        setTitle("Skylink Airlines - Login");
        setSize(380, 220);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // center

        // Username label + field
        JLabel lblUser = new JLabel("Username:");
        lblUser.setBounds(30, 30, 80, 25);
        add(lblUser);

        userField = new JTextField();
        userField.setBounds(120, 30, 200, 25);
        add(userField);

        // Password label + field
        JLabel lblPass = new JLabel("Password:");
        lblPass.setBounds(30, 70, 80, 25);
        add(lblPass);

        passField = new JPasswordField();
        passField.setBounds(120, 70, 200, 25);
        add(passField);

        // Buttons
        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(120, 110, 90, 30);
        add(btnLogin);

        JButton btnReg = new JButton("Register");
        btnReg.setBounds(230, 110, 90, 30);
        add(btnReg);

        // Event: Login
        btnLogin.addActionListener(e -> doLogin());

        // Event: Open Register
        btnReg.addActionListener(e -> {
            dispose();
            new RegisterGUI();
        });

        setVisible(true);
    }

    // Perform login
    private void doLogin() {

        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both fields.");
            return;
        }

        User user = UserService.login(username, password);

        if (user == null) {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
            return;
        }

        JOptionPane.showMessageDialog(this, "Welcome, " + user.getFullName());

        dispose();

        if (user instanceof Admin)
            new AdminDashboard((Admin) user);
        else
            new PassengerDashboard((Passenger) user);
    }
}
