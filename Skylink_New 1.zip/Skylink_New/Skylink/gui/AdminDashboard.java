// -----------------------------------------------------------------------------
// AdminDashboard.java
// Admin control panel → add flights, view bookings, cancel bookings
// -----------------------------------------------------------------------------
package gui;

import models.*;
import services.*;

import javax.swing.*;

public class AdminDashboard extends JFrame {

    private Admin admin;

    public AdminDashboard(Admin a) {

        this.admin = a;

        setTitle("Admin Dashboard - Skylink");
        setSize(400, 260);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel welcome = new JLabel("Admin: " + a.getFullName());
        welcome.setBounds(30, 20, 300, 25);
        add(welcome);

        // Add new flight
        JButton btnAddFlight = new JButton("Add Flight");
        btnAddFlight.setBounds(120, 60, 150, 30);
        add(btnAddFlight);

        // View all bookings
        JButton btnViewBookings = new JButton("View All Bookings");
        btnViewBookings.setBounds(120, 100, 150, 30);
        add(btnViewBookings);

        // Cancel booking
        JButton cancelBookingBtn = new JButton("Cancel Booking");
        cancelBookingBtn.setBounds(120, 140, 150, 30);
        add(cancelBookingBtn);

        cancelBookingBtn.addActionListener(e -> 
            new CancelBookingGUI(true, null).setVisible(true)
        );

        // Logout
        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(120, 180, 150, 30);
        add(btnLogout);

        // Event: Add flight
        btnAddFlight.addActionListener(e -> {
            dispose();
            new AddFlightGUI(admin);
        });

        // Event: View bookings
        btnViewBookings.addActionListener(e -> {
            dispose();
            new ViewBookingsGUI(admin);
        });

        // Event: Logout
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginGUI();
        });

        setVisible(true);
    }
}
