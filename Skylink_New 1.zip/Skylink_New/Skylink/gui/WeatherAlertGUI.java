package gui;

import models.Booking;
import models.Flight;
import models.Passenger;
import services.BookingService;
import services.FlightService;
import services.WeatherAlertService;

import javax.swing.*;
import java.util.ArrayList;

public class WeatherAlertGUI extends JFrame {

    public WeatherAlertGUI(Passenger passenger) {

        setTitle("Weather Alert Notification");
        setSize(500, 350);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel lbl = new JLabel("Select a flight to view weather alert:");
        lbl.setBounds(20, 10, 350, 25);
        add(lbl);

        JComboBox<String> flightBox = new JComboBox<>();
        flightBox.setBounds(20, 50, 440, 30);
        add(flightBox);

        JButton btnCheck = new JButton("Check Weather");
        btnCheck.setBounds(150, 100, 180, 35);
        add(btnCheck);

        JTextArea output = new JTextArea();
        output.setEditable(false);
        output.setLineWrap(true);
        output.setWrapStyleWord(true);
        JScrollPane pane = new JScrollPane(output);
        pane.setBounds(20, 150, 440, 140);
        add(pane);

        // Load bookings for passenger
        ArrayList<Booking> list = BookingService.getBookingsForUser(passenger.getUsername());
        for (Booking b : list) {
            Flight flight = FlightService.getById(b.getFlightId());
            if (flight != null) {
                flightBox.addItem(flight.getFlightId() + " - " + flight.getDestination());
            }
        }

        btnCheck.addActionListener(e -> {
            if (flightBox.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "No flights found or selected");
                return;
            }

            String selected = flightBox.getSelectedItem().toString();
            String destination = selected.split("-")[1].trim();

            String alert = WeatherAlertService.getWeatherAlert(destination);
            output.setText(alert);
        });

        setVisible(true);
    }
}
